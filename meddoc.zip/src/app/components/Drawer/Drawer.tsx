import React from "react";

const App: React.FC<{}> = () => {
    return (<div>Drawer</div>)

}