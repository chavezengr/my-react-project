import {
  Box,
  Toolbar,
  IconButton,
  Typography,
  Button,
  AppBar,
  Tabs,
  Tab,
  Drawer,
} from "@mui/material";
import React from "react";
import { Link, Outlet } from "react-router-dom";
import PhoneIcon from "@mui/icons-material/Phone";
import FavoriteIcon from "@mui/icons-material/Favorite";
import PersonPinIcon from "@mui/icons-material/PersonPin";
import CssBaseline from "@mui/material/CssBaseline";

const AppBarComponent: React.FC = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <div>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <AppBar
          position="fixed"
          sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}
        >
          <Toolbar>
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              aria-label="menu"
              sx={{ mr: 2 }}
            >
              Icon
            </IconButton>

            {/* <Tabs
              value={value}
              onChange={handleChange}
              aria-label="nav tabs example"
              centered
            > */}
            <Tab
              icon={<PhoneIcon />}
              aria-label="person"
              to="/"
              component={Link}
            />
            <Tab
              icon={<FavoriteIcon />}
              aria-label="person"
              to="/clinics"
              component={Link}
            />
            <Tab
              icon={<PersonPinIcon />}
              aria-label="person"
              to="/products"
              component={Link}
            />
            {/* </Tabs> */}

            <Button color="inherit">Login</Button>
          </Toolbar>
        </AppBar>

        <Outlet />
      </Box>
    </div>
  );
};

export default AppBarComponent;
