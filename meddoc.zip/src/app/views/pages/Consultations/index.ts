import Clinics from "./Clinics/Clinics";

export { Clinics }