import React from 'react'

const Clinics: React.FC = () => {
  return (
    <div> Clinics </div>
  )
}

export default Clinics