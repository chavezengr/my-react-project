import React from 'react'

const Pharmacies: React.FC = () => {
  return (
    <div> Pharmacies </div>
  )
}

export default Pharmacies