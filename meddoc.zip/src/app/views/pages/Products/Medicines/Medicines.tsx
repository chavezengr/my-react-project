import React from "react";
import { NavLink, Outlet, Route, useSearchParams } from "react-router-dom";
import routes from "../../../../routes";

const Medicines: React.FC = () => {
  return (
    <>
      Medicines
    </>
  );
};

export default Medicines;
