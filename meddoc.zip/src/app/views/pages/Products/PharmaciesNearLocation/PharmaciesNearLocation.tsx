import React from 'react'

const PharmaciesNearLocation: React.FC = () => {
  return (
    <div> PharmaciesNearLocation </div>
  )
}

export default PharmaciesNearLocation