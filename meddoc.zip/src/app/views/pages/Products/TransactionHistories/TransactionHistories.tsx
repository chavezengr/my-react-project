import React from 'react'

const TransactionHistories: React.FC = () => {
  return (
    <div> TransactionHistories </div>
  )
}

export default TransactionHistories