import React from "react";

const PublicWall: React.FC = () => {
  return <div> PublicWall </div>;
};

export default PublicWall;
