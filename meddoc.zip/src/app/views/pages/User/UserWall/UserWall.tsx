import React from 'react'

const UserWall: React.FC = () => {
  return (
    <div> UserWall </div>
  )
}

export default UserWall