import UserWall from "./UserWall/UserWall";

export { UserWall }