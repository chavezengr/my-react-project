import React from 'react'
import './App.css'

const App: React.FC = () => {
  return (
    <div> HELLO </div>
  )
}

export default App