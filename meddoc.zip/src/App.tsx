import React from "react";
import { BrowserRouter, Link, Outlet, Route, Routes } from "react-router-dom";
import AppBarComponent from "./app/components/Appbar/AppBar";
import routes from "./app/routes";
import { PublicWall } from "./app/views/pages/Home";
import { Medicines, SideMenu, TransactionHistories } from "./app/views/pages/Products";
import { UserWall } from "./app/views/pages/User";


const App: React.FC<{}> = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppBarComponent />}>
          {/* <Route index element={<Invoices />} />
          <Route path="expenses" element={<Expenses />} />
          <Route path="invoices" element={<Invoices />}>
            <Route path=":invoiceId" element={<Invoice />} />
          </Route> */}

          <Route index element={<PublicWall />} />
          <Route path="/products" element={<SideMenu routes={routes.productRoutes} />}>
            <Route index element={<Medicines />} />
            {routes.productRoutes.map(({ path, element: Element }) => (
              <Route path={path} element={<Element />}></Route>
            ))}
          </Route>

          {/* {routes.navRoutes.map(({ path, element: Element }) => (
            <Route path={path} element={<Element />} >
            </Route>
          ))} */}
        </Route>

        <Route
          path="*"
          element={
            <main style={{ padding: "1rem" }}>
              <p>404 Not Found!</p>
            </main>
          }
        />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
